> Cópia derivada de `docs/personas-index.md` para v1.3.1. Revisão-base: `fad18c4624293c4408487efb95e5103a5cfe470b`.
> SHA-256 da fonte antes da adaptação dos links: `9811293e42801f5e0fa1ed5b6849214fa4b3c4c20af7bae3daa25267c7d46bc6`. [URL da fonte](https://github.com/victorsmelo/aios-vmelo/blob/main/docs/personas-index.md); consultar a nota da versão para o estado de publicação.

# Índice de personas

**Versão:** 2026-09-07

As 20 personas são configurações de atuação em domínios específicos. AIOS, FOCUS, skills e conectores não aparecem como personas.

## Trabalho — Sistema de Design e Operações de Design

- [DSYS](personas/trabalho-design-system-and-operacoes-de-design/DSYS.md)
- [DOPS](personas/trabalho-design-system-and-operacoes-de-design/DOPS.md)
- [CSYS](personas/trabalho-design-system-and-operacoes-de-design/CSYS.md)
- [A11Y](personas/trabalho-design-system-and-operacoes-de-design/A11Y.md)
- [UXR](personas/trabalho-design-system-and-operacoes-de-design/UXR.md)
- [ZHUB](personas/trabalho-design-system-and-operacoes-de-design/ZHUB.md)
- [T0OL](personas/trabalho-design-system-and-operacoes-de-design/T0OL.md)
- [FGM8](personas/trabalho-design-system-and-operacoes-de-design/FGM8.md)
- [ENTC](personas/trabalho-design-system-and-operacoes-de-design/ENTC.md)

## Pessoal — Conhecimento, Saúde e Cultura

- [AILIB](personas/pessoal-conhecimento-and-saude/AILIB.md)
- [KNOW](personas/pessoal-conhecimento-and-saude/KNOW.md)
- [FITS](personas/pessoal-conhecimento-and-saude/FITS.md) — treino, hipertrofia, nutrição e recuperação.
- [BHKR](personas/pessoal-conhecimento-and-saude/BHKR.md) — farmacologia, peptídeos, hormônios e biohacking.
- [EVNT](personas/pessoal-conhecimento-and-saude/EVNT.md)

## Jurídico e Política

- [AXIS](personas/pessoal-conhecimento-and-saude/AXIS.md)
- [LEX](personas/pessoal-conhecimento-and-saude/LEX.md)

## Família — Assuntos familiares e escolares

- [KOGN](personas/familia-assuntos-familiares-e-escolares/KOGN.md)
- [KHELP](personas/familia-assuntos-familiares-e-escolares/KHELP.md)
- [SOUL](personas/familia-assuntos-familiares-e-escolares/SOUL.md)

## Estratégia — Disciplina e Liderança

- [F0NT](personas/estrategia-disciplina-and-lideranca/F0NT.md)

AXIS e LEX pertencem ao grupo Jurídico e Política; seus caminhos anteriores são mantidos para preservar os links. Todas as personas seguem o [modelo completo](templates/persona-template.md), com Produto e saídas em uma única seção, distinguindo resultado esperado e formato.
